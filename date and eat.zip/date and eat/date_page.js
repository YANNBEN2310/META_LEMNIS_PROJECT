const swipeCanvas = document.getElementById('swipeCanvas');
const userProfiles = document.querySelectorAll('.userProfile');
const reactionButtons = document.querySelectorAll('.reactionButton');

let startX, startY, currentX, currentY;

swipeCanvas.addEventListener('touchstart', (e) => {
    startX = e.touches[0].clientX;
    startY = e.touches[0].clientY;
});

swipeCanvas.addEventListener('touchmove', (e) => {
    currentX = e.touches[0].clientX;
    currentY = e.touches[0].clientY;

    userProfiles.forEach((profile) => {
        profile.style.transform = `translate3d(${currentX - startX}px, ${currentY - startY}px, 0)`;
    });
});

swipeCanvas.addEventListener('touchend', (e) => {
    const distanceX = currentX - startX;
    const distanceY = currentY - startY;
    const threshold = 100;

    if (Math.abs(distanceX) > threshold || Math.abs(distanceY) > threshold) {
        const direction = distanceX > 0 ? 'right' : (distanceX < 0 ? 'left' : (distanceY < 0 ? 'top' : null));
        userProfiles.forEach((profile) => {
            profile.classList.add(`swipe-${direction}`);
            setTimeout(() => {
                profile.style.transform = 'translate3d(0, 0, 0)';
                profile.classList.remove(`swipe-${direction}`);
            }, 400);
        });
    }
});

reactionButtons.forEach((button) => {
    button.addEventListener('click', (e) => {
        const direction = e.target.dataset.direction;
        userProfiles.forEach((profile) => {
            profile.classList.add(`swipe-${direction}`);
            setTimeout(() => {
                profile.style.transform = 'translate3d(0, 0, 0)';
                profile.classList.remove(`swipe-${direction}`);
            }, 400);
        });
    });
});

const header = document.querySelector('header');
const footer = document.querySelector('footer');
const sidebar = document.querySelector('#sidebar');

header.addEventListener('mouseover', () => {
  sidebar.style.display = 'block';
});

header.addEventListener('mouseout', () => {
  sidebar.style.display = 'none';
});

footer.addEventListener('mouseover', () => {
  sidebar.style.display = 'block';
});

footer.addEventListener('mouseout', () => {
  sidebar.style.display = 'none';
});

sidebar.addEventListener('mouseover', () => {
    sidebar.style.display = 'block';
    header.style.display = 'none';
    footer.style.display = 'none';
  });
  
  sidebar.addEventListener('mouseout', () => {
    sidebar.style.display = 'none';
    header.style.display = 'flex';
    footer.style.display = 'flex';
  });


  const images = ['f (1).webp', 'f (2).webp', 'f (3).webp','f (4).webp' ,'f (5).webp' ,'f (6).webp',
  ,'f (7).webp', 'f (8).webp', 'f (9).webp' ,'f (10).webp' ,'f (11).webp',/*...*/];

  let currentIndex = 0;
  function updateBackground() {
    const img = document.createElement('img');
    img.src = `food/${images[currentIndex]}`;
    document.getElementById('backgroundSlideshow').innerHTML = '';
    document.getElementById('backgroundSlideshow').appendChild(img);
    img.classList.add('fade-in');
    void img.offsetWidth; // This line triggers reflow
    setTimeout(() => {
      img.classList.remove('fade-in');
    }, 1000); // Remove fade-in class after 1 second (adjust this time to match the transition duration in your CSS)
    currentIndex = (currentIndex + 1) % images.length;
  }
  
  
updateBackground();
setInterval(updateBackground, 5000);


  

